建立可以讓chrome plugin執行鍵盤按下左及右鍵時自動執行下一頁及上一頁

上一頁
<a class="paginate_button next" aria-controls="table-list" data-dt-idx="next" tabindex="0" id="table-list_next">下一頁</a>

下一頁
<a class="paginate_button previous" aria-controls="table-list" data-dt-idx="previous" tabindex="0" id="table-list_previous">上一頁</a>
