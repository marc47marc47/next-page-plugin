/**
 * Anime Next - 鍵盤導航擴充功能
 * Content Script
 *
 * @version 1.0.0
 * @description 使用鍵盤左右鍵控制網頁上一頁/下一頁
 */

(function() {
  'use strict';

  // 配置常數
  const CONFIG = {
    BUTTON_SELECTORS: {
      NEXT_ID: 'table-list_next',
      PREVIOUS_ID: 'table-list_previous',
      NEXT_CLASS: 'paginate_button.next',
      PREVIOUS_CLASS: 'paginate_button.previous'
    },
    DISABLED_CLASS: 'disabled',
    CACHE_TIMEOUT: 5000, // 快取過期時間（毫秒）
    DEBOUNCE_DELAY: 50  // 防抖延遲（毫秒）
  };

  // 設定狀態
  let settings = {
    enabled: true,
    visualFeedback: true
  };

  // 按鈕快取
  let buttonCache = {
    next: null,
    previous: null,
    lastUpdate: 0
  };

  // 防抖計時器
  let debounceTimer = null;

  // MutationObserver 實例
  let mutationObserver = null;

  /**
   * 載入設定
   */
  async function loadSettings() {
    try {
      const result = await chrome.storage.sync.get({
        enabled: true,
        visualFeedback: true
      });

      settings = result;
      console.log('[Anime Next] 設定已載入:', settings);
    } catch (error) {
      console.error('[Anime Next] 載入設定失敗:', error);
    }
  }

  /**
   * 檢查元素是否為輸入類型元素
   * @param {HTMLElement} element - 要檢查的元素
   * @returns {boolean} 如果是輸入元素返回 true
   */
  function isInputElement(element) {
    if (!element) return false;

    const tagName = element.tagName.toLowerCase();
    const isEditable = element.isContentEditable;

    return ['input', 'textarea', 'select'].includes(tagName) || isEditable;
  }

  /**
   * 查找分頁按鈕（基礎版本）
   * @param {string} type - 按鈕類型 ('next' 或 'previous')
   * @returns {HTMLElement|null} 找到的按鈕元素或 null
   */
  function findButtonDirect(type) {
    // 策略 1: 透過 ID 查找
    const idMap = {
      'next': CONFIG.BUTTON_SELECTORS.NEXT_ID,
      'previous': CONFIG.BUTTON_SELECTORS.PREVIOUS_ID
    };
    let button = document.getElementById(idMap[type]);

    if (button) {
      console.log(`[Anime Next] 找到按鈕 (ID): ${type}`);
      return button;
    }

    // 策略 2: 透過 class 查找
    const classSelector = type === 'next'
      ? CONFIG.BUTTON_SELECTORS.NEXT_CLASS
      : CONFIG.BUTTON_SELECTORS.PREVIOUS_CLASS;
    button = document.querySelector(`.${classSelector}`);

    if (button) {
      console.log(`[Anime Next] 找到按鈕 (Class): ${type}`);
      return button;
    }

    // 策略 3: 透過 data 屬性查找
    button = document.querySelector(`[data-dt-idx="${type}"]`);

    if (button) {
      console.log(`[Anime Next] 找到按鈕 (Data): ${type}`);
      return button;
    }

    return null;
  }

  /**
   * 更新按鈕快取
   */
  function updateButtonCache() {
    const now = Date.now();

    buttonCache.next = findButtonDirect('next');
    buttonCache.previous = findButtonDirect('previous');
    buttonCache.lastUpdate = now;

    console.log('[Anime Next] 按鈕快取已更新', {
      hasNext: !!buttonCache.next,
      hasPrevious: !!buttonCache.previous
    });
  }

  /**
   * 獲取快取的按鈕（帶自動更新）
   * @param {string} type - 按鈕類型 ('next' 或 'previous')
   * @returns {HTMLElement|null} 找到的按鈕元素或 null
   */
  function getCachedButton(type) {
    const now = Date.now();

    // 如果快取過期或為空，重新查找
    if (now - buttonCache.lastUpdate > CONFIG.CACHE_TIMEOUT || !buttonCache.next || !buttonCache.previous) {
      updateButtonCache();
    }

    return buttonCache[type];
  }

  /**
   * 查找分頁按鈕（帶快取）
   * @param {string} type - 按鈕類型 ('next' 或 'previous')
   * @returns {HTMLElement|null} 找到的按鈕元素或 null
   */
  function findButton(type) {
    // 先嘗試從快取獲取
    let button = getCachedButton(type);

    // 如果快取的按鈕不在 DOM 中，清除快取並重新查找
    if (button && !document.contains(button)) {
      console.log(`[Anime Next] 快取的按鈕已失效，重新查找: ${type}`);
      buttonCache[type] = null;
      button = findButtonDirect(type);
      buttonCache[type] = button;
    }

    return button;
  }

  /**
   * 清除按鈕快取
   */
  function clearButtonCache() {
    buttonCache.next = null;
    buttonCache.previous = null;
    buttonCache.lastUpdate = 0;
    console.log('[Anime Next] 按鈕快取已清除');
  }

  /**
   * 添加視覺回饋效果
   * @param {HTMLElement} button - 要添加效果的按鈕元素
   */
  function addVisualFeedback(button) {
    // 只有在啟用視覺回饋時才添加效果
    if (!settings.visualFeedback) {
      return;
    }

    // 添加動畫 class
    button.classList.add('anime-next-clicked');

    // 600ms 後移除 class（與 CSS 動畫時長一致）
    setTimeout(() => {
      button.classList.remove('anime-next-clicked');
    }, 600);
  }

  /**
   * 點擊下一頁按鈕
   */
  function clickNextButton() {
    const button = findButton('next');

    if (!button) {
      console.log('[Anime Next] 找不到下一頁按鈕');
      return;
    }

    if (button.classList.contains(CONFIG.DISABLED_CLASS)) {
      console.log('[Anime Next] 下一頁按鈕已停用');
      return;
    }

    console.log('[Anime Next] 點擊下一頁按鈕');
    button.click();
    addVisualFeedback(button);
  }

  /**
   * 點擊上一頁按鈕
   */
  function clickPreviousButton() {
    const button = findButton('previous');

    if (!button) {
      console.log('[Anime Next] 找不到上一頁按鈕');
      return;
    }

    if (button.classList.contains(CONFIG.DISABLED_CLASS)) {
      console.log('[Anime Next] 上一頁按鈕已停用');
      return;
    }

    console.log('[Anime Next] 點擊上一頁按鈕');
    button.click();
    addVisualFeedback(button);
  }

  /**
   * 防抖處理的鍵盤事件
   * @param {KeyboardEvent} event - 鍵盤事件
   */
  function handleKeyDownDebounced(event) {
    // 清除之前的計時器
    if (debounceTimer) {
      clearTimeout(debounceTimer);
    }

    // 設定新的計時器
    debounceTimer = setTimeout(() => {
      handleKeyDownImmediate(event);
    }, CONFIG.DEBOUNCE_DELAY);
  }

  /**
   * 處理鍵盤事件（立即執行）
   * @param {KeyboardEvent} event - 鍵盤事件
   */
  function handleKeyDownImmediate(event) {
    // 檢查擴充功能是否啟用
    if (!settings.enabled) {
      return;
    }

    // 如果焦點在輸入元素中，不處理
    if (isInputElement(event.target)) {
      return;
    }

    // 處理左右方向鍵
    switch (event.key) {
      case 'ArrowLeft':
        event.preventDefault();
        clickPreviousButton();
        break;

      case 'ArrowRight':
        event.preventDefault();
        clickNextButton();
        break;
    }
  }

  /**
   * 處理鍵盤事件（主要入口）
   * @param {KeyboardEvent} event - 鍵盤事件
   */
  function handleKeyDown(event) {
    // 對於方向鍵，我們直接執行而不使用防抖
    // 因為使用者期望即時回應
    handleKeyDownImmediate(event);
  }

  /**
   * 設定 MutationObserver 監聽 DOM 變化
   */
  function setupMutationObserver() {
    // 如果已經存在，先斷開連接
    if (mutationObserver) {
      mutationObserver.disconnect();
    }

    // 建立新的 observer
    mutationObserver = new MutationObserver((mutations) => {
      // 檢查是否有分頁相關的變化
      let shouldUpdateCache = false;

      for (const mutation of mutations) {
        // 如果有新增或移除節點
        if (mutation.type === 'childList') {
          // 檢查是否涉及分頁按鈕
          const addedNodes = Array.from(mutation.addedNodes);
          const removedNodes = Array.from(mutation.removedNodes);

          const hasPaginationChange = [...addedNodes, ...removedNodes].some(node => {
            if (node.nodeType !== Node.ELEMENT_NODE) return false;

            const element = node;
            // 檢查是否為分頁相關元素
            return (
              element.classList?.contains('paginate_button') ||
              element.classList?.contains('pagination') ||
              element.querySelector?.('.paginate_button') ||
              element.querySelector?.('[data-dt-idx]')
            );
          });

          if (hasPaginationChange) {
            shouldUpdateCache = true;
            break;
          }
        }

        // 如果有屬性變化（如 class 或 disabled）
        if (mutation.type === 'attributes') {
          const target = mutation.target;
          if (
            target.classList?.contains('paginate_button') ||
            target.hasAttribute?.('data-dt-idx')
          ) {
            shouldUpdateCache = true;
            break;
          }
        }
      }

      // 如果需要更新快取
      if (shouldUpdateCache) {
        console.log('[Anime Next] 偵測到分頁結構變化，更新快取');
        clearButtonCache();
        updateButtonCache();
      }
    });

    // 開始觀察
    mutationObserver.observe(document.body, {
      childList: true,     // 監聽子節點變化
      subtree: true,       // 監聽所有後代節點
      attributes: true,    // 監聽屬性變化
      attributeFilter: ['class', 'disabled', 'data-dt-idx'] // 只監聽特定屬性
    });

    console.log('[Anime Next] MutationObserver 已啟動');
  }

  /**
   * 監聽來自 background 或 popup 的訊息
   */
  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      console.log('[Anime Next] 收到訊息:', message);

      switch (message.action) {
        case 'updateSettings':
          // 更新設定
          if (message.settings) {
            settings = { ...settings, ...message.settings };
            console.log('[Anime Next] 設定已更新:', settings);

            // 如果擴充功能被停用，顯示提示
            if (!settings.enabled) {
              console.log('[Anime Next] 擴充功能已停用');
            } else {
              console.log('[Anime Next] 擴充功能已啟用');
            }
          }
          sendResponse({ received: true });
          break;

        case 'getStatus':
          // 回傳目前狀態
          sendResponse({
            enabled: settings.enabled,
            visualFeedback: settings.visualFeedback,
            cacheInfo: {
              hasNext: !!buttonCache.next,
              hasPrevious: !!buttonCache.previous,
              age: Date.now() - buttonCache.lastUpdate
            }
          });
          break;

        case 'clearCache':
          // 清除快取
          clearButtonCache();
          sendResponse({ success: true });
          break;

        default:
          console.warn('[Anime Next] 未知的訊息動作:', message.action);
          sendResponse({ error: 'Unknown action' });
      }

      return false;
    });
  }

  /**
   * 監聽儲存變更
   */
  function setupStorageListener() {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === 'sync') {
        console.log('[Anime Next] 儲存區域變更:', changes);

        if (changes.enabled) {
          settings.enabled = changes.enabled.newValue;
          console.log('[Anime Next] 啟用狀態已變更:', settings.enabled);
        }

        if (changes.visualFeedback) {
          settings.visualFeedback = changes.visualFeedback.newValue;
          console.log('[Anime Next] 視覺回饋設定已變更:', settings.visualFeedback);
        }
      }
    });
  }

  /**
   * 初始化：添加事件監聽器
   */
  async function init() {
    console.log('[Anime Next] 開始初始化...');

    // 載入設定
    await loadSettings();

    // 初始化按鈕快取
    updateButtonCache();

    // 設定 MutationObserver
    setupMutationObserver();

    // 添加鍵盤事件監聽器
    document.addEventListener('keydown', handleKeyDown);

    // 設定訊息監聽器
    setupMessageListener();

    // 設定儲存監聽器
    setupStorageListener();

    console.log('[Anime Next] 鍵盤導航已啟用');
    console.log('[Anime Next] 目前設定:', settings);
    console.log('[Anime Next] 快取狀態:', {
      hasNext: !!buttonCache.next,
      hasPrevious: !!buttonCache.previous
    });
  }

  /**
   * 清理資源
   */
  function cleanup() {
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }

    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }

    clearButtonCache();
    console.log('[Anime Next] 資源已清理');
  }

  // 監聽頁面卸載事件，清理資源
  window.addEventListener('beforeunload', cleanup);

  // 啟動擴充功能
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
